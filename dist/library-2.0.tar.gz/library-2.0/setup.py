from setuptools import setup, find_packages

setup(name='library',
      version='2.0',
      author='Adam Lekan',
      author_email=' ',
      packages=find_packages(),
      )